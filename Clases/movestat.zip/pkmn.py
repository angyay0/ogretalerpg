import pygame,sys
import time
from pygame import *


pygame.init()
#medoto_una_imagen_por_Seccion
#de_movimiento_chara
def chara_linea(xa,ya, nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()
    for i in range(int(base_x / xa)):
        anime.append(base.subsurface((i * xa, 0, xa, ya)))
    return anime

#medotodo_en_una_sola_imagen_todas_las_charas
def chara_cubo(xa,ya,nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()

    for j in range(int(base_y / ya)):
	  for i in range(int(base_x / xa)):
       		anime.append(base.subsurface((i * xa, j * ya , xa, ya)))
    return anime

#Funcion_para_animar_personajes
#En_contruccion
	
#cosntructor
ancho,alto=500,400
pantalla = pygame.display.set_mode((ancho,alto))
pygame.display.set_caption('Charas RPG')
typlosion= chara_linea(80,80,'typ.png')


reloj = pygame.time.Clock()
fondo= pygame.image.load('main.jpg')
ttol=600
delta=0
frame=0

while True:
	pantalla.blit(fondo,(0,0))
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()
		
#esta_es_la_animacion_
	if pygame.time.get_ticks()-delta>ttol:
		delta= pygame.time.get_ticks()	
		frame+=1
		if frame>1:
			frame=0
	
	
	pantalla.blit(typlosion[frame],(245,245))
	pygame.display.update()
	reloj.tick(30)













			
