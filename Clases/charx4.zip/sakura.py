import pygame,sys
from pygame import *


pygame.init()
#medoto_una_imagen_por_Seccion
#de_movimiento_chara
def chara_linea(xa,ya, nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()
    for i in range(int(base_x / xa)):
        anime.append(base.subsurface((i * xa, 0, xa, ya)))
    return anime

#medotodo_en_una_sola_imagen_todas_las_charas
def chara_cubo(xa,ya,nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()

    for j in range(int(base_y / ya)):
	  for i in range(int(base_x / xa)):
       		anime.append(base.subsurface((i * xa, j * ya , xa, ya)))
    return anime

#cosntructor
ancho,alto=500,400
pantalla = pygame.display.set_mode((ancho,alto))
pygame.display.set_caption('Charas RPG')

sakura= chara_cubo(45,63,'sakura.png')
sakura_bajo=[sakura[0],sakura[1],sakura[3]]
sakura_izq=[sakura[4],sakura[5],sakura[7]]
sakura_drc=[sakura[8],sakura[9],sakura[11]]
sakura_arriba=[sakura[12],sakura[13],sakura[15]]
reloj = pygame.time.Clock()
fondo= pygame.image.load('main.jpg')
x,y=23,14
saku=sakura_bajo[0]
while True:
	pantalla.blit(fondo,(0,0))
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()
	
	if event.type == KEYDOWN:
		if event.key == K_UP:
			if (y-1)<0:
				y=0
			else:
				y-=5
			for i in range(1,2):
				saku= sakura_arriba[i]
				pantalla.blit(saku,(x,y))
				pygame.time.delay(65)
		if event.key == K_DOWN:
			if (y+63)>= alto:
				y=alto-63
			else:
				y+=5
			for i in range(1,2):
				saku= sakura_bajo[i]
				pantalla.blit(saku,(x,y))
				pygame.time.delay(35)
		if event.key == K_RIGHT:
			if (x+45)>= ancho:
				x=ancho-45
			else:
				x+=5
			for i in range(1,2):
				saku= sakura_drc[i]
				pantalla.blit(saku,(x,y))
				pygame.time.delay(35)
		if event.key == K_LEFT:
			if (x-1)<0:
				x=0
			else:
				x-=5
			for i in range(1,2):
				saku= sakura_izq[i]
				pantalla.blit(saku,(x,y))
				pygame.time.delay(35)
	if event.type == KEYUP:	
		if event.key == K_UP:
			saku=sakura_arriba[0]
		if event.key == K_DOWN:
			saku=sakura_bajo[0]
		if event.key == K_RIGHT:
			saku = sakura_drc[0]
		if event.key == K_LEFT:
			saku = sakura_izq[0]
	pantalla.blit(saku,(x,y))
	pygame.display.update()
	reloj.tick(30)













			
