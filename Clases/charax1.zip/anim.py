import pygame
import sys
from pygame.locals import *

#Aqui_la_magia
def animacion(xa,ya, nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()
    for i in range(int(base_x / xa)):
        anime.append(base.subsurface((i * xa, 0, xa, ya)))
    return anime

pygame.init()

alto= 300
ancho= 500
reloj= pygame.time.Clock()

blanco= (255,255,255)
pantalla = pygame.display.set_mode((ancho,alto))
pygame.display.set_caption('Uso de Charas')
	
jugador_estatico= pygame.image.load('player.png')
	
jugador_dinamico= animacion(28,24,'playermov.png')

jugador = jugador_estatico

x,y=100,100
	

while True:
	pantalla.fill(blanco)
	
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()
	if event.type == KEYDOWN:
		if event.key == K_UP:
			y-=9
			if y<0:
				y=0
			jugador = jugador_dinamico[0]

		if event.key == K_DOWN:
			y+=9
			if y>=alto:
				y=0
			jugador = jugador_dinamico[1]

		if event.key == K_LEFT:
			x-=9
			if x<0:
				x=0
			jugador = jugador_dinamico[0]
		
		if event.key == K_RIGHT:
			x+=9
			if x>=ancho:
				x=0
			jugador2 = jugador_dinamico[1]
	if event.type == KEYUP:
		jugador = jugador_estatico

	pantalla.blit(jugador,(x,y))
	pygame.display.update()
	reloj.tick(30)
