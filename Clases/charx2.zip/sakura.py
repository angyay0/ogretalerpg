import pygame,sys
from pygame import *


pygame.init()

def animacion(xa,ya, nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()
    for i in range(int(base_x / xa)):
        anime.append(base.subsurface((i * xa, 0, xa, ya)))
    return anime
#cosntructor
ancho,alto=700,500
pantalla = pygame.display.set_mode((ancho,alto))
pygame.display.set_caption('Charas RPG')

sakura_up= animacion(45,63,'su.png')
sakura_down= animacion(45,63,'sd.png')
sakura_izq= animacion(45,63,'sq.png')
sakura_drc= animacion(45,63,'sc.png')

sakura= sakura_drc[0]
reloj = pygame.time.Clock()
fondo= (255,255,255)
x,y=140,240


while True:
	pantalla.fill(fondo)
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()
	if event.type == KEYDOWN:
		if event.key == K_UP:
			if (y-1)<0:
				y=0
			else:
				y-=8
			for i in range(2):
				sakura=sakura_up[i+2]
				pantalla.blit(sakura,(x,y))
				pygame.time.delay(25)
			sakura=sakura_up[0]
		if event.key == K_DOWN:
			if (y+63) >= alto:			
				y=(alto-63)
			else:
				y+=8
			for i in range(2):
				sakura=sakura_down[i+2]
				pantalla.blit(sakura,(x,y))
				pygame.time.delay(25)
			sakura=sakura_down[0]
		if event.key == K_LEFT:
			if (x-1) < 0:
				x=0
			else:
				x-=8
			for i in range(2):
				sakura=sakura_izq[i+2]
				pantalla.blit(sakura,(x,y))
				pygame.time.delay(25)
			sakura=sakura_izq[0]
		if event.key == K_RIGHT:
			if (x+45) >= ancho:
				x=(ancho-45)
			else:
				x+=8
			for i in range(2):
				sakura=sakura_drc[i+2]
				pantalla.blit(sakura,(x,y))
				pygame.time.delay(25)
			sakura=sakura_drc[0]

	
	
	pantalla.blit(sakura,(x,y))
	pygame.display.update()
	reloj.tick(30)













			
