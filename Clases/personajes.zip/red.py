import pygame,sys
from pygame import *

pygame.init()
#medoto_una_imagen_por_Seccion
#de_movimiento_chara
def chara_linea(xa,ya, nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()
    for i in range(int(base_x / xa)):
        anime.append(base.subsurface((i * xa, 0, xa, ya)))
    return anime

#medotodo_en_una_sola_imagen_todas_las_charas
def chara_cubo(xa,ya,nombre):
    anime = []
    base = pygame.image.load(nombre).convert_alpha()
    base_x, base_y = base.get_size()

    for j in range(int(base_y / ya)):
	  for i in range(int(base_x / xa)):
       		anime.append(base.subsurface((i * xa, j * ya , xa, ya)))
    return anime

	
#cosntructor
ancho,alto=680,500
pantalla = pygame.display.set_mode((ancho,alto))
pygame.display.set_caption('Charas RPG')

w,h=32,48
poncho= chara_cubo(w,h,'poncho.png')
poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]

reloj = pygame.time.Clock()
x,y=0,0
dx,dy=4,4
db=100
delta=0
frame=0
player=poncho_down[0]

while True:
	pantalla.fill((255,255,255))
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()
                
    	if event.type == KEYDOWN:
            if event.key == K_1:
                    poncho= chara_cubo(w,h,'hespada.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player = poncho_down[0]
            if event.key == K_2:
                    poncho= chara_cubo(w,h,'mespada.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player= poncho_down[0]
            if event.key == K_3:
                    poncho= chara_cubo(w,h,'poncho.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player = poncho_down[0]
	    if event.key == K_4:
                    poncho= chara_cubo(w,h,'chepa.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player = poncho_down[0]
            if event.key == K_5:
                    poncho= chara_cubo(w,h,'mlanza.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player = poncho_down[0]
            if event.key == K_6:
                    poncho= chara_cubo(w,h,'hlanza.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player = poncho_down[0]
	    if event.key == K_7:
                    poncho= chara_cubo(w,h,'merlin.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player = poncho_down[0]
            if event.key == K_8:
                    poncho= chara_cubo(w,h,'mortal.png')
                    poncho_down=[poncho[0],poncho[1],poncho[2],poncho[3]]
                    poncho_izq=[poncho[4],poncho[5],poncho[6],poncho[7]]
                    poncho_drc=[poncho[8],poncho[9],poncho[10],poncho[11]]
                    poncho_up=[poncho[12],poncho[13],poncho[14],poncho[15]]
                    player = poncho_down[0]





	        
	pantalla.blit(player,(x,y))
	pygame.display.update()
	reloj.tick(30)













			
